import json
import logging
import os
import uuid
from urllib.parse import unquote

import boto3
import requests

logger = logging.getLogger()
VALID_EXT = ["mp4", "MOV", "flv", "ogv", "mov"]


def lambda_handler(event, context):
    event = event['Records']
    print(event)
    response = list()
    for event_obj in event:
        bucket_name = event_obj['bucket_name']
        file_obj = event_obj['object_key']
        obj_ext = file_obj.split(".")[-1]
        if obj_ext in VALID_EXT:
            obj_name = unquote(file_obj[:len(file_obj) - (len(obj_ext) + 1)].replace("+", " "))

            aws_file_path = "thumbnails/" + obj_name + "_thumbnail.jpeg"
            tmp_video_path = "/tmp/" + str(uuid.uuid1()) + ".{}".format(obj_ext)
            thumbnail_file = "/tmp/" + str(uuid.uuid1()) + ".jpeg"
            s3 = boto3.client('s3')
            s3.download_file(bucket_name, obj_name + "." + obj_ext, tmp_video_path)

            os.system(
                "yes | /opt/python/ffmpeg -i " + tmp_video_path + " -ss 00:00:01.000 -vframes 1 " + thumbnail_file)
            try:
                s3.upload_file(thumbnail_file, bucket_name, aws_file_path)
            except Exception as e:
                print("error while uploading thumbnail to bucket")
                print(str(e))
            base_url = os.environ.get(event_obj['env'])
            url = base_url + os.environ['web_hook']
            header = {'Content-Type': "Application/json"}
            data = {'video_url': obj_name+"."+obj_ext, 'thumbnail_url': aws_file_path.replace(" ", "+"),
                    "object_id": event_obj['object_id'], "object_type": event_obj['object_type']}
            print(data)
            response.append(data)
            os.remove(tmp_video_path)
            os.remove(thumbnail_file)
        requests.post(url, json.dumps(response), headers=header)
        print("call back sent")
    return {
        'statusCode': 200,
        'body': "Ok."
    }
